{pkgs}: {
  deps = [
    pkgs.php
  ];
}

# PHP Bot Hosting

Telegram-controlled PHP bot hosting with secure Webhooks and PHP CGI execution.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required secret: `TELEGRAM_BOT_TOKEN`
- Optional env: `TELEGRAM_ADMIN_ID`, `TELEGRAM_BASE_URL`, `PHP_UPLOAD_DIR`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/lib/telegram-bot.ts` — Telegram API, file storage, Webhook management, and PHP CGI execution
- `artifacts/api-server/src/routes/telegram.ts` — Telegram and hosted PHP routes
- `attached_assets/bot_1785177050522.py` — original source, redacted to read configuration from environment variables

## Architecture decisions

- The Telegram bot runs inside the existing API service so Replit's managed `/api` routing exposes both the control Webhook and hosted bot Webhooks.
- Uploaded PHP files are syntax-checked and executed through `php-cgi`; each hosted bot has a random Telegram Webhook secret.
- Bot ownership is stored beside each file, so users can only view and control their own uploads; the configured admin can manage all bots.

## Product

- Upload PHP bot files from Telegram
- Start, stop, inspect, and delete uploaded bots
- Route Telegram updates to each PHP file through a secure Webhook
- Provide admin statistics and bulk deletion

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details

import { execFile, spawn } from "node:child_process";
import { randomBytes } from "node:crypto";
import { mkdir, readdir, readFile, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import { logger } from "./logger";

const execFileAsync = promisify(execFile);
const uploadRoot = path.resolve(
  process.env["PHP_UPLOAD_DIR"] ?? path.join(process.cwd(), "bots"),
);
const maxUploadBytes = 10 * 1024 * 1024;
const maxPhpOutputBytes = 2 * 1024 * 1024;
const botIdPattern = /^bot_[a-zA-Z0-9_-]+$/;

type TelegramUpdate = {
  message?: {
    chat: { id: number };
    from?: { id: number };
    text?: string;
    document?: { file_id: string; file_name?: string; file_size?: number };
  };
  callback_query?: {
    id: string;
    data?: string;
    from: { id: number };
    message?: { chat: { id: number }; message_id: number };
  };
};

type TelegramResponse<T = Record<string, unknown>> = {
  ok: boolean;
  result?: T;
  description?: string;
};

type TelegramFile = { file_path: string };
type WebhookInfo = { url?: string };

type BotMetadata = {
  ownerId: number;
  createdAt: string;
  webhookSecret: string;
};

type BotRecord = {
  id: string;
  filePath: string;
  token: string | null;
  metadata: BotMetadata | null;
  size: number;
  modifiedAt: number;
};

const metadataFileName = ".bot.json";
let primaryWebhookSecret: string | null = null;

function getBotToken(): string | null {
  const token = process.env["TELEGRAM_BOT_TOKEN"]?.trim();
  return token || null;
}

function getAdminId(): number | null {
  const value = process.env["TELEGRAM_ADMIN_ID"]?.trim();
  if (!value || !/^\d+$/.test(value)) return null;
  return Number(value);
}

function isAdmin(userId: number): boolean {
  return getAdminId() === userId;
}

function getPublicBaseUrl(): string {
  const configured = process.env["TELEGRAM_BASE_URL"]?.trim();
  const isProduction = process.env["NODE_ENV"] === "production";
  const domain =
    configured ||
    (isProduction
      ? process.env["REPLIT_DOMAINS"]?.split(",")[0]
      : process.env["REPLIT_DEV_DOMAIN"] ||
        process.env["REPLIT_DOMAINS"]?.split(",")[0]);
  const fallbackPort = process.env["PORT"] ?? "8080";
  const base = domain
    ? domain.startsWith("http://") || domain.startsWith("https://")
      ? domain
      : `https://${domain}`
    : `http://localhost:${fallbackPort}`;
  return `${base.replace(/\/+$/, "")}/api`;
}

function botUrl(botId: string): string {
  return `${getPublicBaseUrl()}/bots/${botId}/bot.php`;
}

function primaryWebhookUrl(): string {
  return `${getPublicBaseUrl()}/telegram/webhook`;
}

function getSafeBotDirectory(botId: string): string {
  if (!botIdPattern.test(botId)) {
    throw new Error("Invalid bot id");
  }
  const directory = path.resolve(uploadRoot, botId);
  if (!directory.startsWith(`${uploadRoot}${path.sep}`)) {
    throw new Error("Invalid bot path");
  }
  return directory;
}

async function ensureUploadRoot(): Promise<void> {
  await mkdir(uploadRoot, { recursive: true });
}

async function readMetadata(directory: string): Promise<BotMetadata | null> {
  try {
    const raw = await readFile(path.join(directory, metadataFileName), "utf8");
    const parsed = JSON.parse(raw) as Partial<BotMetadata>;
    if (
      typeof parsed.ownerId !== "number" ||
      typeof parsed.createdAt !== "string" ||
      typeof parsed.webhookSecret !== "string"
    ) {
      return null;
    }
    return parsed as BotMetadata;
  } catch {
    return null;
  }
}

async function writeMetadata(
  directory: string,
  metadata: BotMetadata,
): Promise<void> {
  await writeFile(
    path.join(directory, metadataFileName),
    `${JSON.stringify(metadata, null, 2)}\n`,
    "utf8",
  );
}

function extractToken(content: string): string | null {
  const match = content.match(/\b(\d{6,12}:[A-Za-z0-9_-]{20,})\b/);
  return match?.[1] ?? null;
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function inlineKeyboard(rows: Array<Array<{ text: string; callback_data: string }>>) {
  return { inline_keyboard: rows };
}

async function telegramRequest<T>(
  method: string,
  data?: Record<string, string | number | boolean>,
  tokenOverride?: string,
): Promise<TelegramResponse<T> | null> {
  const token = tokenOverride ?? getBotToken();
  if (!token) {
    logger.error("TELEGRAM_BOT_TOKEN is not configured");
    return null;
  }

  try {
    const response = await fetch(
      `https://api.telegram.org/bot${token}/${method}`,
      {
        method: data ? "POST" : "GET",
        headers: data
          ? { "content-type": "application/x-www-form-urlencoded" }
          : undefined,
        body: data ? new URLSearchParams(stringifyTelegramData(data)) : undefined,
        signal: AbortSignal.timeout(15_000),
      },
    );
    const result = (await response.json()) as TelegramResponse<T>;
    if (!response.ok || !result.ok) {
      logger.warn({ method, status: response.status }, "Telegram API request failed");
    }
    return result;
  } catch (error) {
    logger.warn({ method, err: error }, "Telegram API request errored");
    return null;
  }
}

function stringifyTelegramData(
  data: Record<string, string | number | boolean>,
): Record<string, string> {
  return Object.fromEntries(
    Object.entries(data).map(([key, value]) => [key, String(value)]),
  );
}

async function sendMessage(
  chatId: number,
  text: string,
  replyMarkup?: ReturnType<typeof inlineKeyboard>,
): Promise<void> {
  await telegramRequest("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    ...(replyMarkup ? { reply_markup: JSON.stringify(replyMarkup) } : {}),
  });
}

async function editMessage(
  chatId: number,
  messageId: number,
  text: string,
  replyMarkup?: ReturnType<typeof inlineKeyboard>,
): Promise<void> {
  await telegramRequest("editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: "HTML",
    ...(replyMarkup ? { reply_markup: JSON.stringify(replyMarkup) } : {}),
  });
}

async function answerCallback(
  callbackId: string,
  text: string,
  showAlert = false,
): Promise<void> {
  await telegramRequest("answerCallbackQuery", {
    callback_query_id: callbackId,
    text,
    show_alert: showAlert,
  });
}

async function downloadTelegramFile(fileId: string): Promise<Uint8Array | null> {
  const fileInfo = await telegramRequest<TelegramFile>("getFile", {
    file_id: fileId,
  });
  const filePath = fileInfo?.ok ? fileInfo.result?.file_path : undefined;
  const token = getBotToken();
  if (!filePath || !token) return null;

  try {
    const response = await fetch(
      `https://api.telegram.org/file/bot${token}/${filePath}`,
      { signal: AbortSignal.timeout(30_000) },
    );
    const length = Number(response.headers.get("content-length") ?? 0);
    if (length > maxUploadBytes) return null;
    const content = new Uint8Array(await response.arrayBuffer());
    return content.byteLength <= maxUploadBytes ? content : null;
  } catch (error) {
    logger.warn({ err: error }, "Unable to download Telegram file");
    return null;
  }
}

async function lintPhp(filePath: string): Promise<boolean> {
  try {
    await execFileAsync("php", ["-l", filePath], {
      timeout: 5_000,
      maxBuffer: 256 * 1024,
    });
    return true;
  } catch (error) {
    logger.warn({ err: error }, "Uploaded PHP file failed syntax validation");
    return false;
  }
}

async function getBotRecord(botId: string): Promise<BotRecord | null> {
  try {
    const directory = getSafeBotDirectory(botId);
    const filePath = path.join(directory, "bot.php");
    const fileStats = await stat(filePath);
    const content = await readFile(filePath, "utf8");
    return {
      id: botId,
      filePath,
      token: extractToken(content),
      metadata: await readMetadata(directory),
      size: fileStats.size,
      modifiedAt: fileStats.mtimeMs,
    };
  } catch {
    return null;
  }
}

async function getBotsList(): Promise<BotRecord[]> {
  await ensureUploadRoot();
  const entries = await readdir(uploadRoot, { withFileTypes: true });
  const records: BotRecord[] = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || !botIdPattern.test(entry.name)) continue;
    const record = await getBotRecord(entry.name);
    if (record) records.push(record);
  }
  return records.sort((a, b) => b.modifiedAt - a.modifiedAt);
}

function canAccessBot(record: BotRecord, userId: number): boolean {
  return isAdmin(userId) || record.metadata?.ownerId === userId;
}

async function webhookInfo(token: string): Promise<WebhookInfo | null> {
  const result = await telegramRequest<WebhookInfo>("getWebhookInfo", undefined, token);
  return result?.ok ? result.result ?? null : null;
}

async function setBotWebhook(
  token: string,
  url: string,
  secret: string,
): Promise<boolean> {
  const result = await telegramRequest("setWebhook", {
    url,
    secret_token: secret,
    allowed_updates: JSON.stringify(["message", "callback_query"]),
  }, token);
  return result?.ok === true;
}

async function deleteBotWebhook(token: string): Promise<boolean> {
  const result = await telegramRequest(
    "deleteWebhook",
    { drop_pending_updates: false },
    token,
  );
  return result?.ok === true;
}

async function botStatus(record: BotRecord): Promise<string> {
  if (!record.token) return "⚠️ بدون توكن";
  const info = await webhookInfo(record.token);
  return info?.url === botUrl(record.id) ? "🟢 يعمل" : "🔴 متوقف";
}

function mainMenu(userId: number) {
  const rows = [
    [{ text: "📤 رفع بوت", callback_data: "upload" }],
    [{ text: "📋 بوتاتي", callback_data: "my_bots" }],
    [{ text: "ℹ️ تعليمات", callback_data: "help" }],
  ];
  if (isAdmin(userId)) rows.push([{ text: "⚙️ لوحة التحكم", callback_data: "admin" }]);
  return inlineKeyboard(rows);
}

function botButtons(botId: string) {
  return inlineKeyboard([
    [{ text: "▶️ تشغيل", callback_data: `start_${botId}` }],
    [{ text: "⏹ إيقاف", callback_data: `stop_${botId}` }],
    [{ text: "🗑 حذف", callback_data: `delete_${botId}` }],
    [{ text: "🔙 رجوع", callback_data: "my_bots" }],
  ]);
}

async function uploadBot(
  chatId: number,
  userId: number,
  document: NonNullable<NonNullable<TelegramUpdate["message"]>["document"]>,
): Promise<void> {
  if (!document.file_name?.toLowerCase().endsWith(".php")) {
    await sendMessage(chatId, "❌ أرسل ملفًا بامتداد <code>.php</code> فقط.");
    return;
  }
  if (document.file_size && document.file_size > maxUploadBytes) {
    await sendMessage(chatId, "❌ حجم الملف أكبر من الحد المسموح (10 ميجابايت).");
    return;
  }

  const content = await downloadTelegramFile(document.file_id);
  if (!content) {
    await sendMessage(chatId, "❌ تعذر تنزيل الملف من تيليجرام.");
    return;
  }

  const botId = `bot_${Date.now()}_${randomBytes(4).toString("hex")}`;
  const directory = getSafeBotDirectory(botId);
  const filePath = path.join(directory, "bot.php");
  await mkdir(directory, { recursive: true });
  await writeFile(filePath, content);

  if (!(await lintPhp(filePath))) {
    await rm(directory, { recursive: true, force: true });
    await sendMessage(chatId, "❌ الملف ليس PHP صالحًا، لذلك لم يتم حفظه.");
    return;
  }

  const metadata: BotMetadata = {
    ownerId: userId,
    createdAt: new Date().toISOString(),
    webhookSecret: randomBytes(32).toString("hex"),
  };
  await writeMetadata(directory, metadata);

  const token = extractToken(Buffer.from(content).toString("utf8"));
  const tokenMessage = token
    ? "تم العثور على توكن داخل الملف. لن يتم عرضه في المحادثة."
    : "⚠️ لم يتم العثور على توكن داخل الملف.";
  await sendMessage(
    chatId,
    `✅ <b>تم رفع البوت</b>\n\n` +
      `📁 المعرّف: <code>${escapeHtml(botId)}</code>\n` +
      `🔗 الرابط: <code>${escapeHtml(botUrl(botId))}</code>\n` +
      `${tokenMessage}\n\n` +
      "استخدم زر التشغيل بعد التأكد من أن التوكن صحيح.",
    botButtons(botId),
  );
}

async function renderBotDetail(
  chatId: number,
  messageId: number,
  botId: string,
  userId: number,
): Promise<void> {
  const record = await getBotRecord(botId);
  if (!record || !canAccessBot(record, userId)) {
    await editMessage(chatId, messageId, "❌ البوت غير موجود أو لا تملك صلاحية الوصول إليه.", inlineKeyboard([
      [{ text: "🔙 رجوع", callback_data: "my_bots" }],
    ]));
    return;
  }

  const status = await botStatus(record);
  await editMessage(
    chatId,
    messageId,
    `📁 <b>${escapeHtml(botId)}</b>\n` +
      `🔗 <code>${escapeHtml(botUrl(botId))}</code>\n` +
      `📊 الحالة: ${status}\n` +
      `📦 الحجم: ${record.size} بايت`,
    inlineKeyboard([
      [{ text: "▶️ تشغيل", callback_data: `start_${botId}` }],
      [{ text: "⏹ إيقاف", callback_data: `stop_${botId}` }],
      [{ text: "🗑 حذف", callback_data: `delete_${botId}` }],
      [{ text: "🔙 رجوع", callback_data: "my_bots" }],
    ]),
  );
}

async function listMyBots(
  chatId: number,
  messageId: number,
  userId: number,
): Promise<void> {
  const allBots = await getBotsList();
  const records = allBots.filter((record) => canAccessBot(record, userId));
  if (!records.length) {
    await editMessage(
      chatId,
      messageId,
      "📭 <b>لا توجد بوتات مرفوعة.</b>",
      inlineKeyboard([
        [{ text: "📤 رفع بوت", callback_data: "upload" }],
        [{ text: "🔙 رجوع", callback_data: "back" }],
      ]),
    );
    return;
  }

  const lines: string[] = ["📋 <b>البوتات المرفوعة:</b>", ""];
  for (const record of records) {
    lines.push(
      `📁 <code>${escapeHtml(record.id)}</code> — ${await botStatus(record)}`,
      `🔗 <code>${escapeHtml(botUrl(record.id))}</code>`,
      "",
    );
  }
  const buttons = records.map((record) => [
    { text: `📁 ${record.id}`, callback_data: `detail_${record.id}` },
  ]);
  buttons.push([{ text: "🔙 رجوع", callback_data: "back" }]);
  await editMessage(chatId, messageId, lines.join("\n"), inlineKeyboard(buttons));
}

async function adminPanel(chatId: number, messageId: number): Promise<void> {
  const records = await getBotsList();
  await editMessage(
    chatId,
    messageId,
    `⚙️ <b>لوحة التحكم</b>\n📦 عدد البوتات: ${records.length}`,
    inlineKeyboard([
      [{ text: "📊 الإحصائيات", callback_data: "stats" }],
      [{ text: "🗑 مسح الكل", callback_data: "reset" }],
      [{ text: "🔙 رجوع", callback_data: "back" }],
    ]),
  );
}

async function processCallback(
  callback: NonNullable<TelegramUpdate["callback_query"]>,
): Promise<void> {
  const message = callback.message;
  if (!message || !callback.data) return;
  const { chat, message_id: messageId } = message;
  const data = callback.data;
  const userId = callback.from.id;

  if (data === "back") {
    await editMessage(chat.id, messageId, "🤖 <b>بوت استضافة PHP</b>\nاختر أحد الخيارات:", mainMenu(userId));
    return;
  }
  if (data === "upload") {
    await editMessage(chat.id, messageId, "📤 أرسل ملف <code>.php</code> لرفعه.", inlineKeyboard([
      [{ text: "🔙 رجوع", callback_data: "back" }],
    ]));
    return;
  }
  if (data === "help") {
    await editMessage(
      chat.id,
      messageId,
      "📖 <b>التعليمات</b>\n\n1. أرسل ملف PHP.\n2. افتح تفاصيله واضغط تشغيل.\n3. أوقفه أو احذفه من نفس القائمة.\n\nلن يتم عرض توكنات البوتات في الرسائل.",
      inlineKeyboard([[{ text: "🔙 رجوع", callback_data: "back" }]]),
    );
    return;
  }
  if (data === "admin" && isAdmin(userId)) {
    await adminPanel(chat.id, messageId);
    return;
  }
  if (data === "stats" && isAdmin(userId)) {
    const records = await getBotsList();
    const statuses = await Promise.all(records.map(botStatus));
    const running = statuses.filter((status) => status === "🟢 يعمل").length;
    await editMessage(
      chat.id,
      messageId,
      `📊 <b>الإحصائيات</b>\n📦 الكل: ${records.length}\n🟢 يعمل: ${running}\n🔴 متوقف: ${records.length - running}`,
      inlineKeyboard([[{ text: "🔙 رجوع", callback_data: "admin" }]]),
    );
    return;
  }
  if (data === "reset" && isAdmin(userId)) {
    const records = await getBotsList();
    for (const record of records) {
      if (record.token) await deleteBotWebhook(record.token);
      await rm(path.dirname(record.filePath), { recursive: true, force: true });
    }
    await editMessage(
      chat.id,
      messageId,
      "🗑 تم حذف جميع البوتات.",
      inlineKeyboard([[{ text: "🔙 رجوع", callback_data: "admin" }]]),
    );
    return;
  }
  if (data === "my_bots") {
    await listMyBots(chat.id, messageId, userId);
    return;
  }

  const match = data.match(/^(detail|start|stop|delete)_(bot_[a-zA-Z0-9_-]+)$/);
  if (!match) {
    await answerCallback(callback.id, "❌ خيار غير معروف", true);
    return;
  }
  const [, action, botId] = match;
  const record = await getBotRecord(botId);
  if (!record || !canAccessBot(record, userId)) {
    await answerCallback(callback.id, "❌ لا تملك صلاحية الوصول لهذا البوت.", true);
    return;
  }

  if (action === "detail") {
    await renderBotDetail(chat.id, messageId, botId, userId);
    return;
  }
  if (!record.token) {
    await answerCallback(callback.id, "❌ لا يوجد توكن صالح داخل الملف.", true);
    return;
  }

  if (action === "start") {
    const metadata =
      record.metadata ?? {
        ownerId: userId,
        createdAt: new Date().toISOString(),
        webhookSecret: randomBytes(32).toString("hex"),
      };
    await writeMetadata(path.dirname(record.filePath), metadata);
    const started = await setBotWebhook(record.token, botUrl(botId), metadata.webhookSecret);
    if (started) {
      await answerCallback(callback.id, "✅ تم التشغيل", true);
      await renderBotDetail(chat.id, messageId, botId, userId);
    } else {
      await answerCallback(callback.id, "❌ فشل تعيين Webhook.", true);
    }
    return;
  }

  if (action === "stop") {
    const stopped = await deleteBotWebhook(record.token);
    if (stopped) {
      await answerCallback(callback.id, "⏹ تم الإيقاف", true);
      await renderBotDetail(chat.id, messageId, botId, userId);
    } else {
      await answerCallback(callback.id, "❌ فشل الإيقاف.", true);
    }
    return;
  }

  await deleteBotWebhook(record.token);
  await rm(path.dirname(record.filePath), { recursive: true, force: true });
  await answerCallback(callback.id, "🗑 تم الحذف", true);
  await editMessage(chat.id, messageId, `🗑 تم حذف <code>${escapeHtml(botId)}</code>.`, inlineKeyboard([
    [{ text: "🔙 رجوع", callback_data: "my_bots" }],
  ]));
}

async function processUpdate(update: TelegramUpdate): Promise<void> {
  if (update.message) {
    const { chat, from, text, document } = update.message;
    const userId = from?.id ?? chat.id;
    if (text === "/start") {
      await sendMessage(
        chat.id,
        "🤖 <b>بوت استضافة PHP</b>\nمرحبًا! أرسل ملف <code>.php</code> لرفعه وتشغيله.\n\nاختر أحد الخيارات:",
        mainMenu(userId),
      );
    } else if (text === "/help") {
      await sendMessage(chat.id, "📖 أرسل ملف PHP ثم استخدم أزرار التشغيل والإيقاف.", mainMenu(userId));
    }
    if (document) await uploadBot(chat.id, userId, document);
  }
  if (update.callback_query) {
    await answerCallback(update.callback_query.id, "جارٍ التنفيذ...");
    await processCallback(update.callback_query);
  }
}

async function runPhpCgi(
  filePath: string,
  method: string,
  body: string,
  headers: Record<string, string | string[] | undefined>,
): Promise<{ status: number; headers: Record<string, string | string[]>; body: Buffer }> {
  return await new Promise((resolve, reject) => {
    const contentType = headers["content-type"];
    const child = spawn("php-cgi", ["-d", "display_errors=0", "-f", filePath], {
      cwd: path.dirname(filePath),
      env: {
        ...process.env,
        REDIRECT_STATUS: "1",
        REQUEST_METHOD: method,
        CONTENT_TYPE:
          typeof contentType === "string" ? contentType : "application/json",
        CONTENT_LENGTH: String(Buffer.byteLength(body)),
        SCRIPT_FILENAME: filePath,
        SCRIPT_NAME: `/bots/${path.basename(path.dirname(filePath))}/bot.php`,
        REQUEST_URI: `/bots/${path.basename(path.dirname(filePath))}/bot.php`,
        QUERY_STRING: "",
        REMOTE_ADDR: "telegram",
      },
      stdio: "pipe",
    });
    const output: Buffer[] = [];
    let outputSize = 0;
    let errorOutput = "";
    let settled = false;
    const timeout = setTimeout(() => {
      child.kill("SIGKILL");
      if (!settled) {
        settled = true;
        reject(new Error("PHP webhook timed out"));
      }
    }, 10_000);

    child.stdout.on("data", (chunk: Buffer) => {
      outputSize += chunk.length;
      if (outputSize <= maxPhpOutputBytes) output.push(chunk);
      else child.kill("SIGKILL");
    });
    child.stderr.on("data", (chunk: Buffer) => {
      errorOutput += chunk.toString("utf8").slice(0, 2048);
    });
    child.on("error", (error) => {
      clearTimeout(timeout);
      if (!settled) {
        settled = true;
        reject(error);
      }
    });
    child.on("close", (code) => {
      clearTimeout(timeout);
      if (settled) return;
      settled = true;
      if (code !== 0) {
        reject(new Error(`PHP exited with code ${code}: ${errorOutput}`));
        return;
      }
      resolve(parseCgiOutput(Buffer.concat(output)));
    });
    child.stdin.end(body);
  });
}

function parseCgiOutput(output: Buffer): {
  status: number;
  headers: Record<string, string | string[]>;
  body: Buffer;
} {
  const separator = output.indexOf(Buffer.from("\r\n\r\n"));
  const separatorLength = separator >= 0 ? 4 : 2;
  const splitAt = separator >= 0 ? separator : output.indexOf(Buffer.from("\n\n"));
  if (splitAt < 0) return { status: 200, headers: {}, body: output };

  const headerText = output.subarray(0, splitAt).toString("utf8");
  const responseBody = output.subarray(splitAt + separatorLength);
  const responseHeaders: Record<string, string | string[]> = {};
  let status = 200;
  for (const line of headerText.split(/\r?\n/)) {
    const index = line.indexOf(":");
    if (index < 0) continue;
    const key = line.slice(0, index).trim();
    const value = line.slice(index + 1).trim();
    if (key.toLowerCase() === "status") {
      status = Number.parseInt(value, 10) || 200;
    } else if (["content-type", "location", "cache-control", "set-cookie"].includes(key.toLowerCase())) {
      const previous = responseHeaders[key];
      responseHeaders[key] = previous
        ? Array.isArray(previous)
          ? [...previous, value]
          : [previous, value]
        : value;
    }
  }
  return { status, headers: responseHeaders, body: responseBody };
}

export async function handleTelegramWebhook(
  request: { headers: Record<string, string | string[] | undefined>; body?: unknown },
): Promise<void> {
  const configuredSecret = primaryWebhookSecret;
  if (!configuredSecret || request.headers["x-telegram-bot-api-secret-token"] !== configuredSecret) {
    throw new Error("Invalid Telegram webhook secret");
  }
  await processUpdate((request.body ?? {}) as TelegramUpdate);
}

export async function handlePhpWebhook(
  botId: string,
  request: {
    method: string;
    headers: Record<string, string | string[] | undefined>;
    body?: unknown;
  },
): Promise<{ status: number; headers: Record<string, string | string[]>; body: Buffer }> {
  const record = await getBotRecord(botId);
  const secret = record?.metadata?.webhookSecret;
  const receivedSecret = request.headers["x-telegram-bot-api-secret-token"];
  if (!record || !secret || receivedSecret !== secret) {
    throw new Error("Invalid bot webhook secret");
  }
  const body = request.method === "GET" ? "" : JSON.stringify(request.body ?? {});
  return runPhpCgi(record.filePath, request.method, body, request.headers);
}

export async function initializeTelegram(): Promise<void> {
  await ensureUploadRoot();
  const token = getBotToken();
  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN is not configured; Telegram bot is disabled");
    return;
  }
  primaryWebhookSecret = randomBytes(32).toString("hex");
  const configured = await setBotWebhook(token, primaryWebhookUrl(), primaryWebhookSecret);
  if (configured) {
    logger.info({ webhookPath: "/api/telegram/webhook" }, "Telegram webhook configured");
  } else {
    logger.error("Unable to configure the Telegram webhook");
  }
}
import { Router, type IRouter } from "express";
import { handlePhpWebhook, handleTelegramWebhook } from "../lib/telegram-bot";

const router: IRouter = Router();

router.post("/telegram/webhook", (req, res) => {
  void handleTelegramWebhook(req)
    .then(() => res.json({ ok: true }))
    .catch((error: unknown) => {
      req.log.warn({ err: error }, "Rejected Telegram webhook request");
      res.status(403).json({ ok: false });
    });
});

router.all("/bots/:botId/bot.php", (req, res) => {
  void handlePhpWebhook(req.params.botId, req)
    .then((result) => {
      for (const [key, value] of Object.entries(result.headers)) {
        res.setHeader(key, value);
      }
      res.status(result.status).send(result.body);
    })
    .catch((error: unknown) => {
      req.log.warn({ err: error, botId: req.params.botId }, "Rejected PHP bot webhook request");
      res.status(403).json({ ok: false });
    });
});

export default router;
import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { motion } from 'framer-motion';
import {
  Terminal, Zap, Shield, Code,
  ArrowLeft, Server, Cpu, Globe, CheckCircle2,
  Activity, Play, FileCode, Check
} from 'lucide-react';

const queryClient = new QueryClient();

function Navbar() {
  return (
    <header className="fixed top-0 w-full border-b border-border/50 bg-background/80 backdrop-blur-md z-50">
      <div className="container mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center text-primary-foreground shadow-sm">
            <Terminal className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg tracking-tight">استضافة PHP</span>
        </div>
        <div className="flex items-center gap-6">
          <div className="hidden sm:flex items-center gap-2 text-sm font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-100 dark:border-emerald-500/20">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            الأنظمة تعمل
          </div>
          <a 
            href="https://t.me/YourBotUsername" 
            target="_blank" 
            rel="noreferrer" 
            className="px-5 py-2.5 bg-foreground text-background dark:bg-primary dark:text-primary-foreground rounded-lg text-sm font-bold hover:bg-foreground/90 dark:hover:bg-primary/90 transition-all shadow-sm active:scale-95"
          >
            فتح البوت
          </a>
        </div>
      </div>
    </header>
  );
}

function TerminalView() {
  return (
    <div className="w-full max-w-3xl mx-auto rounded-2xl overflow-hidden shadow-2xl shadow-blue-900/10 border border-slate-800 bg-[#0A0A0B]" dir="ltr">
      <div className="flex items-center px-4 py-3 bg-[#131315] border-b border-slate-800">
        <div className="flex gap-2">
          <div className="w-3 h-3 rounded-full bg-rose-500/80" />
          <div className="w-3 h-3 rounded-full bg-amber-500/80" />
          <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
        </div>
        <div className="mx-auto text-xs text-slate-500 font-mono flex items-center gap-2">
          <Terminal className="w-3 h-3" />
          deployment-log.sh
        </div>
      </div>
      <div className="p-6 md:p-8 font-mono text-sm md:text-base text-slate-300 space-y-3 min-h-[340px]">
        <motion.div initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="text-blue-400 font-medium">~</span>$ uploading bot.php...
        </motion.div>
        
        <motion.div initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: 0.8 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="text-emerald-400 font-bold">[OK]</span> File uploaded successfully. (12KB)
        </motion.div>
        
        <motion.div initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: 1.4 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="text-blue-400 font-medium">~</span>$ validating syntax...
        </motion.div>
        
        <motion.div initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: 2.0 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="text-emerald-400 font-bold">[OK]</span> No syntax errors detected.
        </motion.div>
        
        <motion.div initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: 2.6 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="text-blue-400 font-medium">~</span>$ provisioning secure container...
        </motion.div>
        
        <motion.div initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: 3.5 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="text-emerald-400 font-bold">[OK]</span> Container ready (PHP 8.2).
        </motion.div>
        
        <motion.div initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: 4.1 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="text-blue-400 font-medium">~</span>$ setting up webhook...
        </motion.div>
        
        <motion.div initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: 4.8 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="text-emerald-400 font-bold">[OK]</span> Webhook active. Bot is now online!
        </motion.div>
        
        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 5.2, repeat: Infinity, repeatType: "reverse", duration: 0.8 }} viewport={{ once: true, margin: "-100px" }}>
          <span className="w-2.5 h-5 bg-slate-400 inline-block align-middle ml-1"></span>
        </motion.div>
      </div>
    </div>
  );
}

function Home() {
  return (
    <div dir="rtl" className="min-h-[100dvh] bg-background text-foreground font-sans overflow-x-hidden selection:bg-primary/20 selection:text-primary">
      <Navbar />
      
      <main>
        {/* Hero Section */}
        <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
          <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-100/50 via-background to-background dark:from-primary/10"></div>
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              >
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-sm font-bold mb-8 border border-emerald-200 dark:border-emerald-500/20 shadow-sm">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  الخدمة تعمل بكفاءة 100%
                </div>
                
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-foreground mb-6 leading-[1.15]">
                  استضف بوت <span className="text-transparent bg-clip-text bg-gradient-to-l from-primary to-blue-400">تيليجرام</span><br /> بضغطة زر واحدة.
                </h1>
                
                <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
                  أسرع وأسهل طريقة لرفع وتشغيل ملفات PHP الخاصة ببوتات تيليجرام. لا حاجة لإعداد سيرفرات معقدة أو كتابة أوامر، فقط ارفع الملف واترك الباقي علينا.
                </p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <a href="https://t.me/YourBotUsername" target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 w-full sm:w-auto px-8 py-4 bg-primary text-primary-foreground rounded-xl font-bold text-lg hover:bg-primary/90 transition-all shadow-lg shadow-primary/25 hover:shadow-primary/40 active:scale-[0.98]">
                    <Terminal className="w-5 h-5" />
                    ابدأ الاستضافة الآن
                  </a>
                  <a href="#how-it-works" className="flex items-center justify-center gap-2 w-full sm:w-auto px-8 py-4 bg-white dark:bg-secondary text-foreground dark:text-secondary-foreground border border-border rounded-xl font-bold text-lg hover:bg-muted dark:hover:bg-secondary/80 transition-all active:scale-[0.98] shadow-sm">
                    كيف يعمل؟
                    <ArrowLeft className="w-5 h-5" />
                  </a>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Terminal / Live Demo Section */}
        <section className="py-12 md:py-20 relative">
          <div className="container mx-auto px-6">
            <motion.div 
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
              viewport={{ once: true, margin: "-100px" }}
            >
              <TerminalView />
            </motion.div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 border-y border-border/50 bg-slate-50 dark:bg-muted/30 relative overflow-hidden mt-12">
          <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:24px_24px]"></div>
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {[
                { label: "البوتات النشطة", value: "+12,450" },
                { label: "وقت التشغيل", value: "99.99%" },
                { label: "زمن الاستجابة", value: "< 45ms" },
                { label: "الطلبات اليومية", value: "+5M" },
              ].map((stat, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.1, duration: 0.4 }}
                  viewport={{ once: true }}
                  className="flex flex-col items-center justify-center text-center p-4"
                >
                  <span className="text-4xl md:text-5xl font-extrabold text-foreground mb-2 tracking-tight">{stat.value}</span>
                  <span className="text-muted-foreground font-medium">{stat.label}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-24 lg:py-32">
          <div className="container mx-auto px-6">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-3xl lg:text-4xl font-extrabold mb-4">كل ما تحتاجه لإدارة بوتك</h2>
              <p className="text-muted-foreground text-lg">بنية تحتية صممت خصيصاً لتلبية احتياجات مطوري تيليجرام بأعلى معايير الجودة والأمان.</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  icon: <Zap className="w-6 h-6 text-amber-500" />,
                  title: "سرعة استجابة فائقة",
                  description: "خوادمنا متصلة مباشرة بشبكة تيليجرام لضمان أقل وقت استجابة ممكن لبوتك."
                },
                {
                  icon: <Shield className="w-6 h-6 text-emerald-500" />,
                  title: "حماية وعزل تام",
                  description: "يتم تشغيل كل بوت في بيئة معزولة تماماً (Sandbox) لضمان أمان ملفاتك وخصوصيتها."
                },
                {
                  icon: <Code className="w-6 h-6 text-blue-500" />,
                  title: "دعم PHP 8.2",
                  description: "نستخدم أحدث إصدارات PHP مع جميع المكاتب الأساسية لتضمن عمل كودك بدون أخطاء."
                },
                {
                  icon: <Server className="w-6 h-6 text-purple-500" />,
                  title: "موثوقية 99.9%",
                  description: "بنية تحتية قوية تضمن بقاء بوتك متصلاً بالإنترنت على مدار الساعة بدون انقطاع."
                },
                {
                  icon: <Cpu className="w-6 h-6 text-rose-500" />,
                  title: "موارد مخصصة",
                  description: "نظام توزيع موارد ذكي يضمن عدم تأثر بوتك باستهلاك البوتات الأخرى."
                },
                {
                  icon: <Globe className="w-6 h-6 text-teal-500" />,
                  title: "لوحة تحكم مدمجة",
                  description: "تحكم كامل ببوتك من داخل تيليجرام، مع إمكانية عرض سجلات الأخطاء وتحديث الملفات."
                }
              ].map((feature, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1, duration: 0.5 }}
                  viewport={{ once: true }}
                  className="bg-card p-6 md:p-8 rounded-2xl border border-border hover:border-primary/50 transition-colors group shadow-sm hover:shadow-md"
                >
                  <div className="w-14 h-14 rounded-xl bg-slate-100 dark:bg-muted flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-primary/10 transition-all">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-card-foreground">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* How it works Section */}
        <section id="how-it-works" className="py-24 lg:py-32 bg-slate-950 text-white rounded-[2.5rem] mx-4 sm:mx-6 lg:mx-8 mb-12 overflow-hidden relative shadow-2xl">
          <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-primary/30 via-transparent to-transparent"></div>
          <div className="container mx-auto px-6 lg:px-12">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-3xl lg:text-5xl font-extrabold mb-6 text-white leading-tight">خطوات بسيطة<br />لبدء التشغيل</h2>
                <p className="text-slate-400 text-lg mb-12 max-w-lg leading-relaxed">
                  لا تحتاج إلى أي خبرة في إدارة السيرفرات. قمنا بتبسيط العملية لتتمكن من إطلاق بوتك في أقل من دقيقة.
                </p>
                
                <div className="space-y-10">
                  {[
                    {
                      icon: <FileCode className="w-6 h-6 text-blue-400" />,
                      title: "أرسل ملف البوت",
                      desc: "قم بإرسال ملف PHP الخاص بك إلى البوت مباشرة من خلال تيليجرام."
                    },
                    {
                      icon: <Check className="w-6 h-6 text-emerald-400" />,
                      title: "أدخل التوكن",
                      desc: "أرسل توكن البوت الخاص بك الذي حصلت عليه من BotFather."
                    },
                    {
                      icon: <Play className="w-6 h-6 text-purple-400" />,
                      title: "تم التشغيل!",
                      desc: "سيتم ربط الويبهوك تلقائياً وبدء تشغيل البوت فوراً في بيئة آمنة."
                    }
                  ].map((step, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.15, duration: 0.5 }}
                      viewport={{ once: true }}
                      className="flex gap-5"
                    >
                      <div className="flex-shrink-0 w-14 h-14 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center shadow-inner">
                        {step.icon}
                      </div>
                      <div>
                        <h4 className="text-xl font-bold mb-2 text-slate-100">{step.title}</h4>
                        <p className="text-slate-400 leading-relaxed">{step.desc}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
              
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.7 }}
                viewport={{ once: true }}
                className="relative mt-8 lg:mt-0"
              >
                <div className="absolute -inset-4 bg-gradient-to-tr from-primary to-purple-600 rounded-3xl blur-2xl opacity-20"></div>
                <div className="relative bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col gap-4 font-sans" dir="rtl">
                  
                  {/* Chat Bubbles Mock */}
                  <div className="flex flex-col gap-5">
                    <div className="self-end bg-primary text-primary-foreground rounded-2xl rounded-tr-sm px-4 py-3 max-w-[85%] shadow-sm">
                      <div className="flex items-center gap-2 mb-1.5">
                        <FileCode className="w-4 h-4 opacity-80" />
                        <span className="font-mono text-sm" dir="ltr">bot.php</span>
                      </div>
                      <span className="text-xs opacity-70">12.4 KB</span>
                    </div>
                    
                    <div className="self-start bg-slate-800 text-slate-100 rounded-2xl rounded-tl-sm px-4 py-3 max-w-[85%] shadow-sm border border-slate-700/50">
                      <div className="flex items-start gap-2 mb-2">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                        <p className="text-sm font-medium leading-relaxed">
                          تم استلام الملف بنجاح!
                        </p>
                      </div>
                      <p className="text-sm text-slate-300">الرجاء إرسال توكن البوت الخاص بك:</p>
                    </div>

                    <div className="self-end bg-primary text-primary-foreground rounded-2xl rounded-tr-sm px-4 py-3 max-w-[85%] shadow-sm">
                      <span className="font-mono text-sm break-all" dir="ltr">123456789:ABCdefGHIjklMNOpqrsTUVwxyz</span>
                    </div>

                    <div className="self-start bg-slate-800 text-slate-100 rounded-2xl rounded-tl-sm px-4 py-4 max-w-[90%] border border-emerald-500/30 shadow-lg shadow-emerald-900/10">
                      <div className="flex items-center gap-2 mb-3">
                        <Zap className="w-5 h-5 text-amber-400" />
                        <p className="text-base font-bold text-white">تم تشغيل البوت بنجاح!</p>
                      </div>
                      <div className="bg-slate-900/80 rounded-lg p-2.5 mb-3 border border-slate-700/50" dir="ltr">
                        <p className="text-[11px] sm:text-xs text-slate-400 font-mono break-all leading-relaxed">
                          https://api.php-host.bot/wh/123...
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-bold bg-emerald-400/10 w-fit px-2 py-1 rounded">
                        <Activity className="w-3.5 h-3.5" />
                        الحالة: متصل ويعمل
                      </div>
                    </div>
                  </div>

                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-12 bg-slate-50 dark:bg-muted/10">
        <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground">
              <Terminal className="w-4 h-4" />
            </div>
            <span className="font-bold text-lg">استضافة PHP</span>
          </div>
          
          <p className="text-sm font-medium text-muted-foreground text-center md:text-right">
            صُنع بحب للمطورين العرب. جميع الحقوق محفوظة &copy; {new Date().getFullYear()}
          </p>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
        <Switch>
          <Route path="/" component={Home} />
          {/* Fallback to Home since it's a SPA */}
          <Route component={Home} /> 
        </Switch>
      </WouterRouter>
    </QueryClientProvider>
  );
}
